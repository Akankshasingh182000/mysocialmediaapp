from django.apps import AppConfig


class ReminderlistConfig(AppConfig):
    name = 'reminderlist'
