from django.apps import AppConfig


class AuthoConfig(AppConfig):
    name = 'autho'
